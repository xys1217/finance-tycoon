# -*- coding: utf-8 -*-
"""
单页应用后端：静态资源 + 4 个模块的 API
启动:  python3 server.py            # 默认 8899
"""
from __future__ import annotations

import json
import os
import sys
import threading

from flask import Flask, jsonify, request, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
API = os.path.join(HERE, "api")
app = Flask(__name__, static_folder=HERE, static_url_path="")

sys.path.insert(0, os.path.join(HERE, "modules", "analyze"))


def _load(name):
    p = os.path.join(API, name)
    if not os.path.exists(p):
        return None
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


@app.route("/")
def index():
    return send_from_directory(HERE, "index.html")


@app.route("/<path:p>")
def static_files(p):
    return send_from_directory(HERE, p)


@app.route("/api/quant")
def api_quant():
    d = _load("quant_partial.json")
    return jsonify(d or {"css": "", "html": "<div class='empty'>量化选股片段未生成，运行 python3 build_quant.py</div>"})


@app.route("/api/sentiment")
def api_sentiment():
    return jsonify(_load("sentiment_status.json") or {})


@app.route("/api/mainfund")
def api_mainfund():
    return jsonify(_load("mainfund.json") or {})


@app.route("/api/analyze")
def api_analyze():
    code = (request.args.get("code") or "").strip()
    if not code:
        return jsonify({"error": "缺少 code 参数"})
    try:
        from analyze_stock import analyze
        return jsonify(analyze(code))
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 500


@app.route("/api/refresh", methods=["POST"])
def api_refresh():
    """后台触发重新采集（不阻塞响应）。"""
    what = request.json.get("what") if request.is_json else None
    jobs = {
        "sentiment": [sys.executable, os.path.join(HERE, "modules", "sentiment", "dump_status.py")],
        "mainfund": [sys.executable, os.path.join(HERE, "modules", "mainfund", "fetch_fund.py")],
    }
    if what not in jobs:
        return jsonify({"error": f"未知任务 {what}"}), 400

    def run():
        try:
            import subprocess
            subprocess.run(jobs[what], cwd=HERE, timeout=600,
                           env={**os.environ, "TQDM_DISABLE": "1"})
        except Exception:
            pass

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"ok": True, "msg": f"{what} 采集已在后台启动"})


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8899
    print(f"最强量化大佬 → http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
